<?php $__env->startSection('content'); ?>
  <div class="col-lg-6 d-flex justify-content-center align-items-center min-vh-lg-100">
    <div class="w-100 pt-10 pt-lg-7 pb-7" style="max-width: 25rem;">
      <div class="text-center">
        <div class="mb-4">
          <img class="avatar avatar-xxl avatar-4by3" src="<?php echo e(asset('backend/assets/svg/illustrations/click.svg')); ?>" alt="Image Description">
        </div>

        <h1 class="display-4"><?php echo e(__('Verify Your Email Address')); ?></h1>

         
        <?php if(session('resent')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

        </div>
        <?php endif; ?>


        <span class="d-block text-dark font-weight-bold mb-1">
            <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

            <?php echo e(__('Please follow the link inside to continue.')); ?>,</span>


        

        <p>Didn't receive an email? <a href="#">
            <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('Resend')); ?></button>.
            </form></a></p>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ifocustraining\resources\views/auth/verify.blade.php ENDPATH**/ ?>